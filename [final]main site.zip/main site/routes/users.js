var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;

var User = require('../models/user');
var Request = require('../models/user2');
// Register
router.get('/register', function(req, res){
	res.render('register');
});

router.get('/requestblood', function(req, res){
	res.render('requestblood');
});


// Login
router.get('/login', function(req, res){
	res.render('login');
});

// Register User
router.post('/register', function(req, res){
	var name = req.body.name;
	var email = req.body.email;
	var username = req.body.username;
	var password = req.body.password;
	var password2 = req.body.password2;
	var bloodgroup = req.body.bloodgroup;
	var city = req.body.city;
	var state = req.body.state;
	var pincode = req.body.pincode;	
	var timeblood = req.body.timeblood;
	var cutimeblood = req.body.cutimeblood;
	var adonor = req.body.adonor;
	var donor  = true;
	// Validation
	req.checkBody('name', 'Name is required').notEmpty();
	req.checkBody('email', 'Email is required').notEmpty();
	req.checkBody('email', 'Email is not valid').isEmail();
	req.checkBody('username', 'Username is required').notEmpty();
	req.checkBody('password', 'Password is required').notEmpty();
	req.checkBody('password2', 'Passwords do not match').equals(req.body.password);
	req.checkBody('bloodgroup', 'Blood Group Required').notEmpty();
	req.checkBody('city', 'City Required').notEmpty();
	req.checkBody('state', 'State Required').notEmpty();
	req.checkBody('pincode', 'Pincode Required').notEmpty();
    req.checkBody('adonor', 'You have to agree with the terms & conditions to register').isBoolean();
	var errors = req.validationErrors();

	if(errors){
		res.render('register',{
			errors:errors
		});
	} else {
		var newUser = new User({
			name: name,
			email:email,
			username: username,
			password: password,
			bloodgroup: bloodgroup,
			city: city,
			state: state,
			pincode: pincode,
			timeblood: timeblood,
			cutimeblood: cutimeblood,
			adonor: adonor,
			donor: donor
		});

		User.createUser(newUser, function(err, user){
			if(err) throw err;
			console.log(user);
			
		});

		req.flash('success_msg', 'You are registered and can now login');

		res.redirect('/users/login');
	}
});

router.post('/requestblood', function(req, res){
	var name = req.body.name;
	var number = req.body.number;
	var email = req.body.email;
	var area = req.body.Area;
	var pincode = req.body.pincode;
	var reqbloodgroup = req.body.reqbloodgroup;
	var city = req.body.city;
	var state = req.body.state;

	// Validation
	req.checkBody('name', 'Name is required').notEmpty();
	req.checkBody('number', 'Phone Number is required').notEmpty();
	req.checkBody('email', 'Email is not valid').isEmail();
	req.checkBody('area', 'Area/Locality is required').notEmpty();
	req.checkBody('pincode', 'Pincode is required').notEmpty();
	req.checkBody('reqbloodgroup', 'Blood Group Required').notEmpty();
	req.checkBody('city', 'City Required').notEmpty();
	req.checkBody('state', 'State Required').notEmpty();
	req.checkBody('pincode', 'Pincode Required').notEmpty();

	var errors = req.validationErrors();

	if(errors){
		res.render('requestblood',{
			errors:errors});
	} else {
		var newUser = new Request({
			name: name,
			number: number,
			email:email,
			area: area,
			reqbloodgroup: reqbloodgroup,
			city: city,
			state: state,
			pincode: pincode
		});

		Request.createUser(newUser, function(err, user){
			if(err) throw err;
			console.log(user);
			
		});

		req.flash('success_msg', 'Your request has been sent!');

		res.redirect('/users/requestblood');
	}
});

passport.use(new LocalStrategy(
  function(username, password, done) {
   User.getUserByUsername(username, function(err, user){
   	if(err) throw err;
   	if(!user){
   		return done(null, false, {message: 'Unknown User'});
   	}

   	User.comparePassword(password, user.password, function(err, isMatch){
   		if(err) throw err;
   		if(isMatch){
   			return done(null, user);
   		} else {
   			return done(null, false, {message: 'Invalid password'});
   		}
   	});
   });
  }));

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  User.getUserById(id, function(err, user) {
    done(err, user);
  });
});

router.post('/login',
  passport.authenticate('local', {successRedirect:'/', failureRedirect:'/users/login',failureFlash: true}),
  function(req, res) {
    res.redirect('/dashboard');
  });

router.get('/logout', function(req, res){
	req.logout();

	req.flash('success_msg', 'You are logged out');

	res.redirect('/users/login');
});

module.exports = router;